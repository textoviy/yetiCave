<?php

$categories = [
    'boards_skis' => 'Доски и лыжи',
    'mountings' => 'Крепления',
    'boots' => 'Ботинки',
    'clothes' => 'Одежда',
    'instruments' => 'Инструменты',
    'other' => 'Разное'
];

?>