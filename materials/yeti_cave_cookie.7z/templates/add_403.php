<div class="lot-item container fail">
	<h2><b>Хотите добавить лот? </b></h2>
	<p><a href="/login.php">Авторизуйтесь</a>, если есть аккаунт.
        <br><a href="/sign-up.php">Зарегистрируйтесь</a>, если нет аккаунта.</p>
</div>
